## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- include = FALSE, eval = F------------------------------------------
#  library(GenEst)
#  vers <- packageVersion("GenEst")
#  today <- Sys.Date()
#  
#  
#  data(wind_cleared)
#  data_SE <- wind_cleared$SE
#  data_CP <- wind_cleared$CP
#  data_SS <- wind_cleared$SS
#  data_CO <- wind_cleared$CO
#  data_DWP <- wind_cleared$DWP
#  cpmModSet <- cpmSet(formula_l = l ~ Visibility*Season,
#                 formula_s = s ~ Visibility * Season, data = data_CP,
#                 left = "Left",
#                 right = "Right",
#                 dist = c("exponential", "lognormal", "loglogistic", "weibull")
#               )
#  cpmSetAICcTab(cpmModSet)
#  plot(cpmModSet, specificModel = "dist: lognormal; l ~ Visibility; s ~ 1")
#  mtext(side = 3, line = 2.5, adj = 2, cex = 1.5, col = 2,
#    text = "looks like visibility x season?")
#  
#  cpmModSetSize <- cpmSetSize(formula_l = l ~ Visibility * Season,
#                     formula_s = s ~ Visibility, data = data_CP,
#                     left = "Left",
#                     right = "Right",
#                 dist = c("exponential", "lognormal", "loglogistic", "weibull"),
#                     sizeclassCol = "Size"
#                   )
#  cpmSetAICcTab(cpmModSetSize[["bat"]]) # weibull: l ~ Visibility; s ~ 1
#  cpmSetAICcTab(cpmModSetSize[["lrg"]]) # weibull: l ~ 1; l ~ Visibility
#  cpmSetAICcTab(cpmModSetSize[["med"]]) # lognormal: l ~ Visibility; l ~ Visibility
#  cpmSetAICcTab(cpmModSetSize[["sml"]]) # weibull: l ~ 1; l ~ 1
#  
#  cpMods <- c(
#    bat = "dist: weibull; l ~ Visibility; s ~ 1",
#    lrg = "dist: weibull; l ~ 1; s ~ Visibility",
#    med = "dist: lognormal; l ~ Visibility; s ~ Visibility",
#    sml = "dist: weibull; l ~ 1; s ~ 1"
#  )
#  
#  pkmModSetSize <- pkmSetSize(
#    formula_p = p ~ Visibility*Season,
#    formula_k = k ~ Visibility*Season,
#    data = data_SE, sizeclassCol = "Size"
#  )
#  pkmSetAICcTab(pkmModSetSize[["bat"]]) # p ~ Visibility * Season; k ~ 1
#  pkmSetAICcTab(pkmModSetSize[["lrg"]]) # p ~ Visibility; k ~ Visibility
#  pkmSetAICcTab(pkmModSetSize[["med"]]) # p ~ Visibility; k ~ 1
#  pkmSetAICcTab(pkmModSetSize[["sml"]]) # p ~ Visibility; k ~ 1
#  
#  pkMods <- c(
#    bat = "p ~ Visibility * Season; k ~ 1",
#    lrg = "p ~ Visibility; k ~ Visibility",
#    med = "p ~ Visibility; k ~ 1",
#    sml = "p ~ Visibility; k ~ 1"
#  )
#  
#  
#  pkmModSize <- trimSetSize(pkmModSetSize, pkMods)
#  cpmModSize <- trimSetSize(cpmModSetSize, cpMods)
#  
#  
#  DWPcolnames <- names(pkmModSize)
#  nsim = 100; data_CO = data_CO; data_SS = data_SS; data_DWP = data_DWP; frac = 0.23;
#          model_SE = pkmModSize; model_CP = cpmModSize; seed_SE = NULL;
#          seed_CP = NULL; seed_g = NULL; seed_M = NULL; kFill = NULL;
#          unitCol = "Turbine"; dateFoundCol = "DateFound";
#          datesSearchedCol = "SearchDate"; DWPCol = DWPcolnames;
#          sizeclassCol = "Size";
#  cullWindow = NULL; seed_g = NULL; seed_ghat = NULL;
#  
#  eM <- estM(nsim = 100, data_CO, data_SS, data_DWP, frac = 0.23,
#          model_SE = pkmModSize, model_CP = cpmModSize, seed_SE = NULL,
#          seed_CP = NULL, seed_g = NULL, seed_M = NULL, kFill = NULL,
#          unitCol = "Turbine", dateFoundCol = "DateFound",
#          datesSearchedCol = "SearchDate", DWPCol = DWPcolnames,
#          sizeclassCol = "Size")
#  summary(eM)
#  plot(eM)
#  
#  M_season <- calcSplits(M = eM$M, Aj = eM$Aj, split_SS = "Season",
#                   split_CO = NULL, data_SS = data_SS, data_CO = data_CO)
#  summary(M_season)
#  plot(M_season)
#  M_size <- calcSplits(M = eM$M, Aj = eM$Aj, split_SS = NULL,
#               split_CO = "Size", data_SS = data_SS, data_CO = data_CO)
#  summary(M_size)
#  plot(M_size)
#  
#  M_SbyC <- calcSplits(M = eM$M, Aj = eM$Aj, split_SS = "Season",
#              split_CO = "Species", data_SS = data_SS, data_CO = data_CO
#            )
#  summary(M_SbyC)
#  plot(transposeSplits(M_SbyC))
#  
#  M_by_species <- calcSplits(M = eM$M, Aj = eM$Aj, split_CO = "SpeciesGroup", data_CO = data_CO)
#  

