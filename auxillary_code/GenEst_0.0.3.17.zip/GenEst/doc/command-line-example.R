## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- include = FALSE----------------------------------------------------
library(GenEst)
vers <- packageVersion("GenEst")
today <- Sys.Date()

## ---- eval = FALSE-------------------------------------------------------
#  install.packages("devtools")
#  devtools::install_github("ddalthorp/GenEst")
#  library(GenEst)

## ------------------------------------------------------------------------
data(mockData)
names(mockData)

## ------------------------------------------------------------------------
dataSE <- mockData$SearcherEfficiencyData
pkModel <- pkm(formula_p = p ~ 1, formula_k = k ~ 1, data = dataSE)

## ------------------------------------------------------------------------
head(dataSE)

## ------------------------------------------------------------------------
pkModel <- pkm(formula_p = p ~ 1, formula_k = k ~ 1, data = dataSE, 
             obsCol = c("Search1", "Search2", "Search3", "Search4")
           )

## ------------------------------------------------------------------------
pkModel

## ------------------------------------------------------------------------
names(pkModel)
pkModel$cells

## ---- fig.show = "hold", fig.width = 7, fig.height = 7-------------------
plot(pkModel)

## ------------------------------------------------------------------------
rpk(n = 10, pkModel)

## ------------------------------------------------------------------------
pkm(formula_p = p ~ Visibility, formula_k = k ~ HabitatType, data = dataSE,
  obsCol = c("Search1", "Search2", "Search3", "Search4")
)

## ------------------------------------------------------------------------
pkm(formula_p = p ~ Visibility, kFixed = 0.7, data = dataSE,
  obsCol = c("Search1", "Search2", "Search3", "Search4")
)

## ------------------------------------------------------------------------
pkmModSet <- pkmSet(formula_p = p ~ Visibility*HabitatType, 
               formula_k = k ~ HabitatType, data = dataSE,
               obsCol = c("Search1", "Search2", "Search3", "Search4")
             )
names(pkmModSet)

## ---- fig.show = "hold", fig.width = 7, fig.height = 7-------------------
plot(pkmModSet, specificModel = "p ~ Visibility + HabitatType; k ~ 1")

## ------------------------------------------------------------------------
pkmSetAICcTab(pkmModSet)

## ------------------------------------------------------------------------
pkmModSetSize <- pkmSetSize(formula_p = p ~ Visibility*HabitatType, 
                   formula_k = k ~ HabitatType, data = dataSE,
                   obsCol = c("Search1", "Search2", "Search3", "Search4"),
                   sizeclassCol = "Size"
                 )

## ------------------------------------------------------------------------
names(pkmModSetSize)
names(pkmModSetSize[[1]])

## ------------------------------------------------------------------------
dataCP <- mockData$CarcassPersistenceData
cpModel <- cpm(formula_l = l ~ 1, formula_s = s ~ 1, data = dataCP,
             left = "LastPresentDecimalDays", 
             right = "FirstAbsentDecimalDays", dist = "weibull"
           )

## ------------------------------------------------------------------------
cpModel

## ------------------------------------------------------------------------
names(cpModel)
cpModel$cells

## ---- fig.show = "hold", fig.width = 7, fig.height = 7-------------------
plot(cpModel)

## ------------------------------------------------------------------------
rcp(n = 10, cpModel)
rcp(n = 10, cpModel, type = "ppersist")

## ------------------------------------------------------------------------
cpm(formula_l = l ~ Visibility*GroundCover, formula_s = s ~ 1, data = dataCP,
  left = "LastPresentDecimalDays", right = "FirstAbsentDecimalDays", 
  dist = "weibull"
)

## ------------------------------------------------------------------------
cpModExp <- cpm(formula_l = l ~ Visibility*GroundCover, data = dataCP,
              left = "LastPresentDecimalDays", 
              right = "FirstAbsentDecimalDays", dist = "exponential"
            )

## ------------------------------------------------------------------------
cpmModSet <- cpmSet(formula_l = l ~ Visibility*Season, 
               formula_s = s ~ Visibility, data = dataCP,
               left = "LastPresentDecimalDays", 
               right = "FirstAbsentDecimalDays", 
               dist = c("exponential", "lognormal")
             )
names(cpmModSet)

## ------------------------------------------------------------------------
cpmSetAICcTab(cpmModSet)

## ---- fig.show = "hold", fig.width = 7, fig.height = 7-------------------
plot(cpmModSet, 
  specificModel = "dist: lognormal; l ~ Visibility * Season; s ~ Visibility")

## ------------------------------------------------------------------------
cpmModSetSize <- cpmSetSize(formula_l = l ~ Visibility*Season, 
                   formula_s = s ~ Visibility, data = dataCP,
                   left = "LastPresentDecimalDays", 
                   right = "FirstAbsentDecimalDays", 
                   dist = c("exponential", "lognormal"),
                   sizeclassCol = "Size"
                 )

## ------------------------------------------------------------------------
names(cpmModSetSize)
names(cpmModSetSize[[1]])

## ------------------------------------------------------------------------
pkModel <- GenEst::pkm(formula_p = p ~ Visibility * HabitatType, 
                       formula_k = k ~ 1, data = dataSE)
cpModel <- GenEst::cpm(formula_l = l ~ Season, formula_s = s ~ 1, 
             data = dataCP,
             left = "LastPresentDecimalDays", 
             right = "FirstAbsentDecimalDays", dist = "weibull")
dataCO <- mockData$CarcassObservationData
dataSS <- mockData$SearchScheduleData
ghatsAs <- rghat(n = 1000, dataCO, dataSS, model_SE = pkModel, 
             model_CP = cpModel, seed_SE = 1, seed_CP = 1,
             unitCol = "Unit", dateFoundCol = "DateFound", 
             dateSearchedCol = "DateSearched"
           )
ghats <- ghatsAs$ghat

## ------------------------------------------------------------------------
Mhat <- rMhat(n = 1, ghat = ghats)

