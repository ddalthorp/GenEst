#' @title Create the main reactive value list for GenEst 
#'
#' @description Create a list of reactive values as used across the components
#'   of the GenEst application
#'
#' @return a reactive values list
#'
#' @export
#'
createReactiveValues <- function(){
  reactiveValues(
    data_SE = NULL, data_CP = NULL, data_SS = NULL, data_DWP = NULL, 
    data_CO = NULL,
    colNames_SE = NULL, colNames_SE_sel = NULL, colNames_SE_nosel = NULL, 
    colNames_CP = NULL, colNames_CP_sel = NULL, colNames_CP_nosel = NULL,    
    colNames_SS = NULL, colNames_SS_sel = NULL, colNames_SS_nosel = NULL, 
    colNames_DWP = NULL,
    colNames_CO = NULL, colNames_COdates = NULL,
    colNames_all = NULL, 

    nsim = 1000, CL = 0.95, 

    sizeclassCol = NULL, sizeclasses = NULL, sizeclass = NULL, 
    sizeclass_SE = NULL, sizeclass_CP = NULL, sizeclass_g = NULL,
    sizeclass_M = NULL,

    obsCols_SE = NULL, preds_SE = NULL, predictors_SE = NULL, 
    formula_p = NULL, formula_k = NULL, kFixedChoice = NULL, kFixed = NULL, 
    mods_SE = NULL, mods_SE_og = NULL, sizeclasses_SE = NULL, 
    outSEpk = NULL, AICcTab_SE = NULL, modOrder_SE = NULL, modNames_SE = NULL,
    modNames_SEp = NULL, modNames_SEk = NULL, modSet_SE = NULL,
    best_SE = NULL, modTab_SE = NULL, modTabPretty_SE = NULL,
    modTabDL_SE = NULL, figH_SE = 800, figW_SE = 800,
    kFill = NULL, 

    ltp = NULL, fta = NULL, preds_CP = NULL, dists = NULL, 
    predictors_CP = NULL, formula_l = NULL, formula_s = NULL, 
    mods_CP = NULL, mods_CP_og = NULL, CPdls = NULL, outCPdlsfig = NULL, 
    outCPdlstab = NULL, sizeclasses_CP = NULL, AICcTab_CP = NULL, 
    modOrder_CP = NULL, modNames_CP = NULL, modNames_CPdist = NULL, 
    modNames_CPl = NULL, modNames_CPs = NULL, modSet_CP = NULL, 
    best_CP = NULL, modTab_CP = NULL, modTabPretty_CP = NULL, 
    modTabDL_CP = NULL, figH_CP = 700, figW_CP = 800,

    M = NULL, Msplit = NULL, unitCol = NULL, frac = 1, 
    sizeclassCol_M = NULL, DWPCol = NULL, dateFoundCol = NULL, 
    SEmodToUse = NULL, CPmodToUse = NULL,
    split_CO = NULL, split_SS = NULL, nsplit_CO = 0, nsplit_SS = 0, 
    figH_M = 800, figW_M = 800,

    SS = seq(0, 364, 7), SStext = paste(seq(0, 364, 7), collapse = ", "),
    kFill_g = NULL, sizeclasses_g = NULL, nsizeclasses_g = NULL,
    gGeneric = NULL, SEmodToUse_g = NULL, CPmodToUse_g = NULL,
    figH_g = 400, figW_g = 800
  )
}