## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- include=FALSE------------------------------------------------------
library(GenEst)
vers <- packageVersion("GenEst")
today <- Sys.Date()

## ------------------------------------------------------------------------
data(mock)
names(mock)

## ------------------------------------------------------------------------
data_SE <- mock$SE
pkModel <- pkm(formula_p = p ~ 1, formula_k = k ~ 1, data = data_SE)

## ------------------------------------------------------------------------
head(data_SE)

## ------------------------------------------------------------------------
pkModel <- pkm(formula_p = p ~ 1, formula_k = k ~ 1, data = data_SE,
             obsCol = c("Search1", "Search2", "Search3", "Search4")
           )

## ------------------------------------------------------------------------
pkModel

## ------------------------------------------------------------------------
names(pkModel)
pkModel$cells

## ---- fig.show = "hold", fig.width = 7, fig.height = 7-------------------
plot(pkModel)

## ------------------------------------------------------------------------
rpk(n = 10, pkModel)

## ------------------------------------------------------------------------
pkm(formula_p = p ~ Visibility, formula_k = k ~ HabitatType, data = data_SE,
  obsCol = c("Search1", "Search2", "Search3", "Search4")
)

## ------------------------------------------------------------------------
pkm(formula_p = p ~ Visibility, kFixed = 0.7, data = data_SE,
  obsCol = c("Search1", "Search2", "Search3", "Search4")
)

## ------------------------------------------------------------------------
pkmModSet <- pkmSet(formula_p = p ~ Visibility*HabitatType,
               formula_k = k ~ HabitatType, data = data_SE,
               obsCol = c("Search1", "Search2", "Search3", "Search4")
             )
names(pkmModSet)

## ---- fig.show = "hold", fig.width = 7, fig.height = 7-------------------
plot(pkmModSet, specificModel = "p ~ Visibility + HabitatType; k ~ 1")

## ------------------------------------------------------------------------
pkmSetAICcTab(pkmModSet)

## ------------------------------------------------------------------------
pkmModSetSize <- pkmSetSize(formula_p = p ~ Visibility*HabitatType,
                   formula_k = k ~ HabitatType, data = data_SE,
                   obsCol = c("Search1", "Search2", "Search3", "Search4"),
                   sizeclassCol = "Size"
                 )

## ------------------------------------------------------------------------
names(pkmModSetSize)
names(pkmModSetSize[[1]])

## ------------------------------------------------------------------------
data_CP <- mock$CP
cpModel <- cpm(formula_l = l ~ 1, formula_s = s ~ 1, data = data_CP,
             left = "LastPresentDecimalDays",
             right = "FirstAbsentDecimalDays", dist = "weibull"
           )

## ------------------------------------------------------------------------
cpModel

## ------------------------------------------------------------------------
names(cpModel)
cpModel$cells

## ---- fig.show = "hold", fig.width = 7, fig.height = 7-------------------
plot(cpModel)

## ------------------------------------------------------------------------
rcp(n = 10, cpModel)
rcp(n = 10, cpModel, type = "ppersist")

## ------------------------------------------------------------------------
cpm(formula_l = l ~ Visibility*GroundCover, formula_s = s ~ 1, data = data_CP,
  left = "LastPresentDecimalDays", right = "FirstAbsentDecimalDays",
  dist = "weibull"
)

## ------------------------------------------------------------------------
cpModExp <- cpm(formula_l = l ~ Visibility*GroundCover, data = data_CP,
              left = "LastPresentDecimalDays",
              right = "FirstAbsentDecimalDays", dist = "exponential"
            )

## ------------------------------------------------------------------------
cpmModSet <- cpmSet(formula_l = l ~ Visibility*Season,
               formula_s = s ~ Visibility, data = data_CP,
               left = "LastPresentDecimalDays",
               right = "FirstAbsentDecimalDays",
               dist = c("exponential", "lognormal")
             )
names(cpmModSet)

## ------------------------------------------------------------------------
cpmSetAICcTab(cpmModSet)

## ---- fig.show = "hold", fig.width = 7, fig.height = 7-------------------
plot(cpmModSet,
  specificModel = "dist: lognormal; l ~ Visibility * Season; s ~ Visibility"
)

## ------------------------------------------------------------------------
cpmModSetSize <- cpmSetSize(formula_l = l ~ Visibility*Season,
                   formula_s = s ~ Visibility, data = data_CP,
                   left = "LastPresentDecimalDays",
                   right = "FirstAbsentDecimalDays",
                   dist = c("exponential", "lognormal"),
                   sizeclassCol = "Size"
                 )

## ------------------------------------------------------------------------
names(cpmModSetSize)
names(cpmModSetSize[[1]])

## ------------------------------------------------------------------------
model_SE <- pkm(formula_p = p ~ Visibility * HabitatType, formula_k = k ~ 1,
             data = data_SE
            )
model_CP <- cpm(formula_l = l ~ Season, formula_s = s ~ 1, 
             data = data_CP,
             left = "LastPresentDecimalDays", 
             right = "FirstAbsentDecimalDays", dist = "weibull"
            )

## ------------------------------------------------------------------------
data_SS <- mock$SS
avgSS <- averageSS(data_SS)
ghatsGeneric <- estghatGeneric(n = 1000, avgSS, model_SE, model_CP, 
                  seed_SE = 1, seed_CP = 1, kFill = NULL)

## ------------------------------------------------------------------------
summary(ghatsGeneric)

## ---- fig.show = "hold", fig.width = 7, fig.height = 7-------------------
plot(ghatsGeneric)

## ---- eval=FALSE---------------------------------------------------------
#  data_CO <- mock$CO
#  ghatsAjs <- estghat(n = 1000, data_CO, data_SS, model_SE, model_CP,
#               seed_SE = 1, seed_CP = 1, unitCol = "Unit",
#               dateFoundCol = "DateFound", dateSearchedCol = "DateSearched",
#             )
#  ghat <- ghatsAjs$ghat
#  Aj <- ghatsAjs$Aj

