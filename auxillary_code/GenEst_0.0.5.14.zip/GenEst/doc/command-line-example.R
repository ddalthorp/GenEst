## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- include = FALSE----------------------------------------------------
library(GenEst)
vers <- packageVersion("GenEst")
today <- Sys.Date()

## ------------------------------------------------------------------------
data(mockData)
names(mockData)

## ------------------------------------------------------------------------
data_SE <- mockData$SearcherEfficiencyData
pkModel <- pkm(formula_p = p ~ 1, formula_k = k ~ 1, data = data_SE)

## ------------------------------------------------------------------------
head(data_SE)

## ------------------------------------------------------------------------
pkModel <- pkm(formula_p = p ~ 1, formula_k = k ~ 1, data = data_SE,
             obsCol = c("Search1", "Search2", "Search3", "Search4")
           )

## ------------------------------------------------------------------------
pkModel

## ------------------------------------------------------------------------
names(pkModel)
pkModel$cells

## ---- fig.show = "hold", fig.width = 7, fig.height = 7-------------------
plot(pkModel)

## ------------------------------------------------------------------------
rpk(n = 10, pkModel)

## ------------------------------------------------------------------------
pkm(formula_p = p ~ Visibility, formula_k = k ~ HabitatType, data = data_SE,
  obsCol = c("Search1", "Search2", "Search3", "Search4")
)

## ------------------------------------------------------------------------
pkm(formula_p = p ~ Visibility, kFixed = 0.7, data = data_SE,
  obsCol = c("Search1", "Search2", "Search3", "Search4")
)

## ------------------------------------------------------------------------
pkmModSet <- pkmSet(formula_p = p ~ Visibility*HabitatType,
               formula_k = k ~ HabitatType, data = data_SE,
               obsCol = c("Search1", "Search2", "Search3", "Search4")
             )
names(pkmModSet)

## ---- fig.show = "hold", fig.width = 7, fig.height = 7-------------------
plot(pkmModSet, specificModel = "p ~ Visibility + HabitatType; k ~ 1")

## ------------------------------------------------------------------------
pkmSetAICcTab(pkmModSet)

## ------------------------------------------------------------------------
pkmModSetSize <- pkmSetSize(formula_p = p ~ Visibility*HabitatType,
                   formula_k = k ~ HabitatType, data = data_SE,
                   obsCol = c("Search1", "Search2", "Search3", "Search4"),
                   sizeclassCol = "Size"
                 )

## ------------------------------------------------------------------------
names(pkmModSetSize)
names(pkmModSetSize[[1]])

## ------------------------------------------------------------------------
data_CP <- mockData$CarcassPersistenceData
cpModel <- cpm(formula_l = l ~ 1, formula_s = s ~ 1, data = data_CP,
             left = "LastPresentDecimalDays",
             right = "FirstAbsentDecimalDays", dist = "weibull"
           )

## ------------------------------------------------------------------------
cpModel

## ------------------------------------------------------------------------
names(cpModel)
cpModel$cells

## ---- fig.show = "hold", fig.width = 7, fig.height = 7-------------------
plot(cpModel)

## ------------------------------------------------------------------------
rcp(n = 10, cpModel)
rcp(n = 10, cpModel, type = "ppersist")

## ------------------------------------------------------------------------
cpm(formula_l = l ~ Visibility*GroundCover, formula_s = s ~ 1, data = data_CP,
  left = "LastPresentDecimalDays", right = "FirstAbsentDecimalDays",
  dist = "weibull"
)

## ------------------------------------------------------------------------
cpModExp <- cpm(formula_l = l ~ Visibility*GroundCover, data = data_CP,
              left = "LastPresentDecimalDays",
              right = "FirstAbsentDecimalDays", dist = "exponential"
            )

## ------------------------------------------------------------------------
cpmModSet <- cpmSet(formula_l = l ~ Visibility*Season,
               formula_s = s ~ Visibility, data = data_CP,
               left = "LastPresentDecimalDays",
               right = "FirstAbsentDecimalDays",
               dist = c("exponential", "lognormal")
             )
names(cpmModSet)

## ------------------------------------------------------------------------
cpmSetAICcTab(cpmModSet)

## ---- fig.show = "hold", fig.width = 7, fig.height = 7-------------------
plot(cpmModSet,
  specificModel = "dist: lognormal; l ~ Visibility * Season; s ~ Visibility"
)

## ------------------------------------------------------------------------
cpmModSetSize <- cpmSetSize(formula_l = l ~ Visibility*Season,
                   formula_s = s ~ Visibility, data = data_CP,
                   left = "LastPresentDecimalDays",
                   right = "FirstAbsentDecimalDays",
                   dist = c("exponential", "lognormal"),
                   sizeclassCol = "Size"
                 )

## ------------------------------------------------------------------------
names(cpmModSetSize)
names(cpmModSetSize[[1]])

## ------------------------------------------------------------------------
model_SE <- pkm(formula_p = p ~ Visibility * HabitatType, formula_k = k ~ 1,
             data = data_SE
            )
model_CP <- cpm(formula_l = l ~ Season, formula_s = s ~ 1, 
             data = data_CP,
             left = "LastPresentDecimalDays", 
             right = "FirstAbsentDecimalDays", dist = "weibull"
            )

## ------------------------------------------------------------------------
data_SS <- mockData$SearchScheduleData
avgSS <- averageSS(data_SS)
ghatsGeneric <- rghatGeneric(n = 1000, avgSS, model_SE, model_CP, 
                  seed_SE = 1, seed_CP = 1, kFill = NULL)

## ------------------------------------------------------------------------
summary(ghatsGeneric)

## ---- fig.show = "hold", fig.width = 7, fig.height = 7-------------------
plot(ghatsGeneric)

## ------------------------------------------------------------------------
data_CO <- mockData$CarcassObservationData
ghatsAjs <- rghat(n = 1000, data_CO, data_SS, model_SE, model_CP,
             seed_SE = 1, seed_CP = 1, unitCol = "Unit",
             dateFoundCol = "DateFound", dateSearchedCol = "DateSearched",
             removeCleanout = TRUE
           )
ghat <- ghatsAjs$ghat
Aj <- ghatsAjs$Aj

## ------------------------------------------------------------------------
Mhat <- rMhat(n = 1, ghat = ghat)

## ------------------------------------------------------------------------
data_DWP <- mockData$DensityWeightedProportionData
DWP <- DWPbyCarcass(data_DWP, data_CO, unitCol = "Unit",
         sizeclassCol = "Size",
         removeCleanout = TRUE, data_SS, dateFoundCol = "DateFound",
         dateSearchedCol = "DateSearched"
       )
Mhat <- rMhat(n = 1, ghat = ghat, DWP, seed = 12)

## ------------------------------------------------------------------------
Mtilde <- rMtilde(length(ghat), ghat, seed = 12)

## ------------------------------------------------------------------------
Mhat_viaMtilde <- calcMhat(Mtilde, DWP)

