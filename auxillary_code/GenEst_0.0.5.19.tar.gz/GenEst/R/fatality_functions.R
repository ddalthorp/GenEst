#' Draw values for Xtilde given a ghat
#'
#' @param n number of random draws
#' @param ghat estimated detection probability
#' @param seed seed used to set the random number generator
#' @return Xtilde 
#' @examples NA
#' @export 
#'
rXtilde <- function(n = 1, ghat, seed = 1){
  set.seed(seed)
  Xtilde <- rcbinom(n, 1 / ghat, ghat)
  return(Xtilde)
}

#' Draw values for Mtilde given a ghat
#'
#' @param n number of random draws
#' @param ghat estimated detection probability
#' @param seed seed used to set the random number generator
#' @return Mtilde 
#' @examples NA
#' @export 
#'
rMtilde <- function(n = 1, ghat, seed = 1){
  
  Xtilde <- rXtilde(n, ghat, seed)
  MtildeVec <- (Xtilde - (Ecbinom(ghat) - 1)) / ghat
  Mtilde <- matrix(MtildeVec, ncol = ncol(ghat))
  return(Mtilde)
}

#' Draw values for Mhat given a ghat and DWP
#'
#' @param n number of random draws per carcass
#' @param ghat estimated detection probability
#' @param DWP Density weighted proportion associated with Mtilde
#' @param seed seed used to set the random number generator
#' @return Mhat 
#' @examples NA
#' @export 
#'
rMhat <- function(n = 1, ghat, DWP = 1, seed = 1){
  
  if (n != 1){
    stop("multiple draws per ghat is not currently available at this time.")
  }
  Mtilde <- rMtilde(n = length(ghat), ghat, seed)
  Mhat <- calcMhat(Mtilde, DWP)
  return(Mhat)
}

#' Calculate Mhat for a given Mtilde and DWP
#'
#' @description If Mtilde is a matrix, DWP is expadanded by columns to match
#'   to facilitate division
#'
#' @param Mtilde Mtilde value
#' @param DWP Density weighted proportion associated with Mtilde
#' @return Mhat 
#' @examples NA
#' @export 
#'
calcMhat <- function(Mtilde, DWP = 1){

  if (!is.null(dim(Mtilde))){
    ncarc <- dim(Mtilde)[1]
    n <- dim(Mtilde)[2]
    if (length(DWP) == 1){
      DWP <- rep(DWP, ncarc)
    } 
    if (dim(Mtilde)[1] != length(DWP)){
      stop("Mtilde and DWP are of different sizes")
    }
    tempDWP <- matrix(NA, nrow = ncarc, ncol = n)
    for (carci in 1:ncarc){
      tempDWP[carci, ] <- rep(DWP[carci], n)
    }
    DWP <- tempDWP
  }
  if (is.vector(Mtilde) & is.vector(DWP)){
    ncarc <- length(Mtilde)
    if (length(DWP) == 1){
      DWP <- rep(DWP, ncarc)
    } 
    if (length(Mtilde) != length(DWP)){
      stop("Mtilde and DWP are of different sizes")
    }
  }

  Mhat <- Mtilde / DWP
  return(Mhat)
}


#' Expand the density weighted proportion table to a value for each carcass
#'
#' @param data_DWP Survey unit (rows) by size (columns) density weighted 
#'   proportion table 
#' @param data_CO Carcass observation data
#' @param data_SS Search Schedule data 
#' @param unitCol Column name for the unit indicator
#' @param sizeclassCol Name of colum in \code{data_CO} where the size 
#'   classes are recorded
#' @param dateFoundCol Column name for the date found data (if cleanout 
#'   searches are to be removed)
#' @param dateSearchedCol Column name for the date searched data (if cleanout 
#'   searches are to be removed)
#' @param DWPCol Column name for the DWP values in the DWP table when no
#'   size class is used
#' @return DWP value for each carcass 
#' @examples NA
#' @export 
#'
DWPbyCarcass <- function(data_DWP, data_CO, unitCol = "Unit",
                         sizeclassCol = NULL, data_SS = NULL, 
                         dateFoundCol = "DateFound",
                         dateSearchedCol = "DateSearched",
                         DWPCol = NULL){

  if (!(unitCol %in% colnames(data_DWP) & unitCol %in% colnames(data_CO))){
    stop("Unit column not in both DWP and carcass tables")
  }
  units_carc <- unique(data_CO[ , unitCol])
  units_DWP <- data_DWP[ , unitCol]
  nunits <- nrow(data_DWP)
  if (!all(units_carc %in% units_DWP)){
    stop("Units present in carcass table not in DWP table")
  }

  data_SS[ , dateSearchedCol] <- yyyymmdd(data_SS[ , dateSearchedCol])
  data_CO[ , dateFoundCol] <- yyyymmdd(data_CO[ , dateFoundCol])
  date0 <- min(data_SS[ , dateSearchedCol])
  data_CO[ , dateFoundCol] <- dateToDay(data_CO[ , dateFoundCol], date0)
  data_SS[ , dateSearchedCol] <- dateToDay(data_SS[ , dateSearchedCol], date0)

  which_day0 <- which(data_SS[ , dateSearchedCol] == 0)
  SSunitCols <- which(colnames(data_SS) %in% unique(data_CO[ , unitCol]))
  data_SS[which_day0, SSunitCols] <- 1

  cleanout <- whichCleanout(data_CO, data_SS, unitCol, dateFoundCol,
                dateSearchedCol
              )  
  if (length(cleanout) > 0){
    data_CO <- data_CO[-cleanout, ]
  }

  if (is.null(sizeclassCol)){
    if (is.null(DWPCol)){
      whichDWPCol <- grep("dwp", colnames(data_DWP), ignore.case = TRUE)
      if (length(whichDWPCol) == 0){
        stop("No DWP data indicated and no obvious choice for DWP column.")
      }     
      DWPCol <- colnames(data_DWP)[whichDWPCol[1]]
    }
    sizeclassCol <- "scc"
    data_CO$scc <- "all"
    sizeclasses <- "all"
  } else{
    if (!(sizeclassCol %in% colnames(data_CO))){
      stop("Provided size class column not present in carcass table")
    }
    sizeclasses <- as.character(unique(data_CO[ , sizeclassCol]))
    DWPCol <- colnames(data_DWP)[colnames(data_DWP) %in% sizeclasses]
    if (!all(sizeclasses %in% DWPCol)){
      stop("Size classes present in carcass table not in DWP table")
    }
  }

  nDWPCol <- length(DWPCol)

  DWPonly <- as.matrix(data_DWP[ , DWPCol], nrow = nunits, ncol = nDWPCol)

  DWPexp <- numeric(0)
  unitexp <- character(0)
  scexp <- character(0)
  for (uniti in 1:nunits){
    DWPexp <- c(DWPexp, DWPonly[uniti, ])
    unitexp <- c(unitexp, rep(as.character(units_DWP[uniti]), nDWPCol))
    scexp <- c(scexp, sizeclasses)
  }
  data_DWPtall <- data.frame(DWPexp, unitexp, scexp, stringsAsFactors = FALSE)
  colnames(data_DWPtall) <- c("DWP", unitCol, sizeclassCol)

  ncarc <- nrow(data_CO)
  DWPbyCarc <- numeric(ncarc)
  for (carci in 1:ncarc){
    unitOfInterest <- data_CO[carci, unitCol]
    matchUnit <- data_DWPtall[ , unitCol] == unitOfInterest
    sizeOfInterest <- data_CO[carci, sizeclassCol]
    matchSize <- data_DWPtall[ , sizeclassCol] == sizeOfInterest
    matchBoth <- matchUnit & matchSize
    DWPbyCarc[carci] <- data_DWPtall[which(matchBoth), "DWP"]
  }
  return(DWPbyCarc)
}

