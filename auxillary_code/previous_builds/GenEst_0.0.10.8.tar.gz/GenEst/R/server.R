#' @title Server-side GenEst
#'
#' @description Run the active server-side code for the GenEst application
#'
#' @param input server input
#'
#' @param output server output
#'
#' @param session server session
#'
#' @return server output
#'
#' @export
#'
server <- function(input, output, session){

modalWelcome()
rv <- createReactiveValues()
output$versionInfo <- renderText(createvtext())
output$SStext <- renderText(rv$SStext)


msg_RunModSE <- NULL
msg_NobsSE <- NULL
msg_ModFailSE <- NULL
msg_SampleSizeSE <- NULL
msg_RunModCP <- NULL
msg_ModFailCP <- NULL
msg_SampleSizeCP <- NULL
msg_avgSSfail <- NULL
msg_RunModg <- NULL
msg_RunModM <- NULL
msg_ModFailM <- NULL
msg_ModFailg <- NULL
msg_splitFail <- NULL


observeEvent(input$file_SE, {
  rv$data_SE <- read.csv(input$file_SE$datapath, stringsAsFactors = FALSE)
  rv$colNames_SE <- colnames(rv$data_SE)
  rv$colNames_all <- updateColNames_all(rv)
  rv$sizeclassCol <- updateSizeclassCol(input$sizeclassCol, rv$colNames_all)
  output$data_SE <- renderDataTable(datatable(rv$data_SE))
  updateTabsetPanel(session, "LoadedDataViz", "Search Efficiency")
  rv$colNames_SE_sel <- c(rv$sizeclassCol)
  rv$colNames_SE_nosel <- removeSelCols(rv$colNames_SE, rv$colNames_SE_sel)
  updateSelectizeInput(session, "preds_SE", choices = rv$colNames_SE_nosel)
  updateSelectizeInput(session, "obsCols_SE", choices = rv$colNames_SE_nosel)
  updateSelectizeInput(session, "sizeclassCol", choices = rv$colNames_all,
    selected = rv$sizeclassCol
  )
})
observeEvent(input$file_CP, {
  rv$data_CP <- read.csv(input$file_CP$datapath, stringsAsFactors = FALSE)
  rv$colNames_CP <- colnames(rv$data_CP)
  rv$colNames_all <- updateColNames_all(rv)
  rv$sizeclassCol <- updateSizeclassCol(input$sizeclassCol, rv$colNames_all)
  output$data_CP <- renderDataTable(datatable(rv$data_CP))
  updateTabsetPanel(session, "LoadedDataViz", "Carcass Persistence")
  rv$colNames_CP_sel <- c(rv$sizeclassCol)
  rv$colNames_CP_nosel <- removeSelCols(rv$colNames_CP, rv$colNames_CP_sel)
  updateSelectizeInput(session, "preds_CP", choices = rv$colNames_CP_nosel)
  updateSelectizeInput(session, "ltp", choices = rv$colNames_CP_nosel)
  updateSelectizeInput(session, "fta", choices = rv$colNames_CP_nosel)
  updateSelectizeInput(session, "sizeclassCol", choices = rv$colNames_all,
    selected = rv$sizeclassCol
  )
})
observeEvent(input$file_SS, {
  rv$data_SS <- read.csv(input$file_SS$datapath, stringsAsFactors = FALSE)
  rv$colNames_SS <- colnames(rv$data_SS)
  output$data_SS <- renderDataTable(datatable(rv$data_SS))
  updateTabsetPanel(session, "LoadedDataViz", "Search Schedule")
})
observeEvent(input$file_DWP, {
  rv$data_DWP <- read.csv(input$file_DWP$datapath, stringsAsFactors = FALSE)
  rv$colNames_DWP <- colnames(rv$data_DWP)
  output$data_DWP<- renderDataTable(datatable(rv$data_DWP))
  updateTabsetPanel(session, "LoadedDataViz", "Density Weighted Proportion")
  updateSelectizeInput(session, "DWPCol", choices = rv$colNames_DWP)
})
observeEvent(input$file_CO, {
  rv$data_CO <- read.csv(input$file_CO$datapath, stringsAsFactors = FALSE)
  rv$colNames_CO <- colnames(rv$data_CO)
  rv$colNames_COdates <- dateCols(rv$data_CO)
  rv$colNames_all <- updateColNames_all(rv)
  rv$sizeclassCol <- updateSizeclassCol(input$sizeclassCol, rv$colNames_all)
  output$data_CO <- renderDataTable(datatable(rv$data_CO))
  updateTabsetPanel(session, "LoadedDataViz", "Carcass Observations")
  updateSelectizeInput(session, "splitCol", choices = rv$colNames_CO)
  updateSelectizeInput(session, "dateFoundCol", choices = rv$colNames_COdates)
  updateSelectizeInput(session, "sizeclassCol", choices = rv$colNames_all,
    selected = rv$sizeclassCol
  )
})

observeEvent(input$sizeclassCol, {
  rv$colNames_SE_sel <- c(input$obsCols_SE, input$sizeclassCol)
  rv$colNames_SE_nosel <- removeSelCols(rv$colNames_SE, rv$colNames_SE_sel)
  updateSelectizeInput(session, "preds_SE", choices = rv$colNames_SE_nosel,
    selected = input$preds_SE)
  rv$colNames_SE_sel <- c(input$preds_SE, input$sizeclassCol)
  rv$colNames_SE_nosel <- removeSelCols(rv$colNames_SE, rv$colNames_SE_sel)
  updateSelectizeInput(session, "obsCols_SE", choices = rv$colNames_SE_nosel,
    selected = input$obsCols_SE)
  rv$colNames_CP_sel <- c(input$preds_CP, input$fta, input$sizeclassCol)
  rv$colNames_CP_nosel <- removeSelCols(rv$colNames_CP, rv$colNames_CP_sel)
  updateSelectizeInput(session, "ltp", choices = rv$colNames_CP_nosel,
    selected = input$ltp)
  rv$colNames_CP_sel <- c(input$preds_CP, input$ltp, input$sizeclassCol)
  rv$colNames_CP_nosel <- removeSelCols(rv$colNames_CP, rv$colNames_CP_sel)
  updateSelectizeInput(session, "fta", choices = rv$colNames_CP_nosel,
    selected = input$fta)
  rv$colNames_CP_sel <- c(input$ltp, input$fta, input$sizeclassCol)
  rv$colNames_CP_nosel <- removeSelCols(rv$colNames_CP, rv$colNames_CP_sel)
  updateSelectizeInput(session, "preds_CP", choices = rv$colNames_CP_nosel,
    selected = input$preds_CP)
})

observeEvent(input$obsCols_SE, {
  selectedCols <- c(input$obsCols_SE, input$sizeclassCol, input$preds_SE)
  selectedData <- selectData(rv$data_SE, selectedCols)
  output$selected_SE <- renderDataTable(datatable(selectedData))
  rv$colNames_SE_sel <- c(input$obsCols_SE, input$sizeclassCol)
  rv$colNames_SE_nosel <- removeSelCols(rv$colNames_SE, rv$colNames_SE_sel)
  updateSelectizeInput(session, "preds_SE", choices = rv$colNames_SE_nosel,
    selected = input$preds_SE)
})
observeEvent(input$preds_SE, {
  selectedCols <- c(input$obsCols_SE, input$sizeclassCol, input$preds_SE)
  selectedData <- selectData(rv$data_SE, selectedCols)
  output$selected_SE <- renderDataTable(datatable(selectedData))
  rv$colNames_SE_sel <- c(input$preds_SE, input$sizeclassCol)
  rv$colNames_SE_nosel <- removeSelCols(rv$colNames_SE, rv$colNames_SE_sel)
  updateSelectizeInput(session, "obsCols_SE", choices = rv$colNames_SE_nosel,
    selected = input$obsCols_SE)
})

observeEvent(input$runMod_SE, {

  clearNotifications(msg_NobsSE = msg_NobsSE)
  clearNotifications(msg_SampleSizeSE = msg_SampleSizeSE)
  clearNotifications(msg_ModFailSE = msg_ModFailSE) 
  msg_RunModSE <- msgModRun("SE")

  rv$obsCols_SE <- input$obsCols_SE
  rv$preds_SE <- input$preds_SE
  rv$kFixed <- setkFix(input$kFixedChoice, input$kFixed)
  rv$nsim <- input$nsim
  rv$CL <- input$CL
  rv$sizeclassCol <- input$sizeclassCol
  rv$kFixedChoice <- input$kFixedChoice
  rv$predictors_SE <- prepPredictors(rv$preds_SE)
  rv$formula_p <- formula(paste("p~", rv$predictors_SE, sep = ""))
  rv$formula_k <- formula(paste("k~", rv$predictors_SE, sep = "")) 

  rv$mods_SE <- suppressWarnings(
                  pkmSetSize(formula_p = rv$formula_p,
                    formula_k = rv$formula_k, data = rv$data_SE, 
                    obsCol = rv$obsCols_SE, sizeclassCol = rv$sizeclassCol,
                    kFixed = rv$kFixed, kInit = 0.7, CL = rv$CL, 
                    quiet = TRUE
                  ) 
                ) 
  if (all(unlist(pkmSetSizeFail(rv$mods_SE)))){

    removeNotification(msg_RunModSE)
    msg_ModFailSE <<- msgModFail(rv$mod_SE)

  } else{

    if (any(unlist(pkmSetSizeFail(rv$mods_SE)))){
      msg_ModFailSE <<- msgModPartialFail()
      rv$mods_SE <- pkmSetSizeFailRemove(rv$mods_SE)
    }
    removeNotification(msg_RunModSE)
    msg_SampleSizeSE <<- msgSampleSize(rv$mod_SE)
    msg_NobsSE <<- msgNobsSE(rv$formula_k, rv$kFixed, rv$obsCols_SE)

    rv$sizeclasses <- updateSizeclasses(rv$data_SE, rv$sizeclassCol)
    rv$sizeclasses_SE <- rv$sizeclasses
    rv$sizeclass <- pickSizeclass(rv$sizeclasses, input$tabfig_sizeclassSE)
    rv$AICcTab_SE <- pkmSetAICcTab(rv$mods_SE[[rv$sizeclass]], TRUE)
    rv$modOrder_SE <- as.numeric(row.names(rv$AICcTab_SE))
    rv$modNames_SE <- names(rv$mods_SE[[rv$sizeclass]])[rv$modOrder_SE]
    rv$modNames_SEp <- modNameSplit(rv$modNames_SE, 1)
    rv$modNames_SEk <- modNameSplit(rv$modNames_SE, 2)
    rv$modSet_SE <- rv$mods_SE[[rv$sizeclass]]
    rv$best_SE <- (names(rv$modSet_SE)[rv$modOrder_SE])[1]
    rv$modTab_SE <- rv$mods_SE[[rv$sizeclass]][[rv$best_SE]]$cellwiseTable
    rv$modTab_SE <- prettyModTabSE(rv$modTab_SE, rv$CL)
    rv$figH_SE <- setFigH(rv$modSet_SE, 800)
    rv$figW_SE <- setFigW(rv$modSet_SE)

    output$SEModDone <- renderText("OK")
    outputOptions(output, "SEModDone", suspendWhenHidden = FALSE)

    output$kFillNeed <- setkFillNeed(rv$obsCols_SE)
    output$AICcTab_SE <- renderDataTable({rv$AICcTab_SE})    
    output$modTab_SE <- renderDataTable({rv$modTab_SE})
    output$fig_SE <- renderPlot({ 
                       plot(rv$modSet_SE, specificModel = rv$best_SE,
                         sizeclassName = rv$sizeclass
                       )},
                       height = rv$figH_SE, width = rv$figW_SE
                     )
    outputOptions(output, "kFillNeed", suspendWhenHidden = FALSE)
    isolate({
      output$sizeclasses_SE <- prepSizeclassText(rv$sizeclasses_SE)
      outputOptions(output, "sizeclasses_SE", suspendWhenHidden = FALSE)
      output$modelMenu_SE <- makeMenu(rv$mods_SE, rv$sizeclasses_SE, "SE")
    })

    updateTabsetPanel(session, "analyses_SE", "Model Comparison")
    updateSelectizeInput(session, "tabfig_SEp", choices = rv$modNames_SEp)
    updateSelectizeInput(session, "tabfig_SEk", choices = rv$modNames_SEk)
    updateSelectizeInput(session, "tabfig_sizeclassSE", 
      choices = rv$sizeclasses
    )
    if (rv$kFixedChoice == 1){
      updateNumericInput(session, "kFill", value = rv$kFixed)
    }
    if (length(rv$sizeclasses) == 1){
      output$DWPNeed <- renderText("yes")
    } else{
      output$DWPNeed <- renderText("no")
    }
    outputOptions(output, "DWPNeed", suspendWhenHidden = FALSE)
    output$sizeclass_SE1 <-  renderText(paste0("Size class: ", rv$sizeclass))
    output$sizeclass_SE2 <-  renderText(paste0("Size class: ", rv$sizeclass))

  }
})

observeEvent(input$tabfig_sizeclassSE, {
  if (length(rv$mods_SE) > 0){
    rv$sizeclass <- pickSizeclass(rv$sizeclasses, input$tabfig_sizeclassSE)
    rv$AICcTab_SE <- pkmSetAICcTab(rv$mods_SE[[rv$sizeclass]], TRUE)
    rv$modOrder_SE <- as.numeric(row.names(rv$AICcTab_SE))
    rv$modNames_SE <- names(rv$mods_SE[[rv$sizeclass]])[rv$modOrder_SE]
    rv$modNames_SEp <- modNameSplit(rv$modNames_SE, 1)
    rv$modNames_SEk <- modNameSplit(rv$modNames_SE, 2)
    rv$modSet_SE <- rv$mods_SE[[rv$sizeclass]]
    rv$best_SE <- (names(rv$modSet_SE)[rv$modOrder_SE])[1]
    rv$modTab_SE <- rv$mods_SE[[rv$sizeclass]][[rv$best_SE]]$cellwiseTable
    rv$modTab_SE <- prettyModTabSE(rv$modTab_SE, rv$CL)
    rv$figH_SE <- setFigH(rv$modSet_SE, 800)
    rv$figW_SE <- setFigW(rv$modSet_SE)

    output$modTab_SE <- renderDataTable(rv$modTab_SE)
    output$fig_SE <- renderPlot({ 
                       plot(rv$modSet_SE, specificModel = rv$best_SE,
                         sizeclassName = rv$sizeclass
                       )},
                       height = rv$figH_SE, width = rv$figW_SE
                     )
    updateSelectizeInput(session, "tabfig_SEp", choices = rv$modNames_SEp)
    updateSelectizeInput(session, "tabfig_SEk", choices = rv$modNames_SEk)

    observeEvent(input$tabfig_SEp, {
      rv$tabfig_SEpk <- modNamePaste(c(input$tabfig_SEp, input$tabfig_SEk))
      rv$modSet_SE <- rv$mods_SE[[rv$sizeclass]]
      rv$modTab_SE <- rv$modSet_SE[[rv$tabfig_SEpk]]$cellwiseTable
      rv$modTab_SE <- prettyModTabSE(rv$modTab_SE, rv$CL)
      output$modTab_SE <- renderDataTable(rv$modTab_SE)
      output$fig_SE <- renderPlot({
                         tryCatch(
                           plot(rv$modSet_SE,
                             specificModel = rv$tabfig_SEpk,
                             sizeclassName = rv$sizeclass
                           ), error = function(x){plot(1,1)}
                         )}, 
                       height = rv$figH_SE, width = rv$figW_SE
                       )
    })
    observeEvent(input$tabfig_SEk, {
      rv$tabfig_SEpk <- modNamePaste(c(input$tabfig_SEp, input$tabfig_SEk))
      rv$modSet_SE <- rv$mods_SE[[rv$sizeclass]]
      rv$modTab_SE <- rv$modSet_SE[[rv$tabfig_SEpk]]$cellwiseTable
      rv$modTab_SE <- prettyModTabSE(rv$modTab_SE, rv$CL)
      output$modTab_SE <- renderDataTable(rv$modTab_SE)
      output$fig_SE <- renderPlot({
                         tryCatch(
                           plot(rv$modSet_SE, 
                             specificModel = rv$tabfig_SEpk,
                             sizeclassName = rv$sizeclass
                           ), error = function(x){plot(1,1)}
                         )}, 
                       height = rv$figH_SE, width = rv$figW_SE
                       )
    })
    rv$AICcTab_SE <- pkmSetAICcTab(rv$mods_SE[[rv$sizeclass]], TRUE)
    output$AICcTab_SE <- renderDataTable(datatable(rv$AICcTab_SE))
    output$sizeclass_SE1 <- renderText(paste0("Size class: ", rv$sizeclass))
    output$sizeclass_SE2 <- renderText(paste0("Size class: ", rv$sizeclass))

    output$downloadSEest <- downloadHandler(
                              filename = "SE_estimates.csv",
                              content = function(file){
                                          write.csv(rv$modTab_SE, file, 
                                          row.names = FALSE)
                                        }
                            )
    output$downloadSEAICc <- downloadHandler(
                               filename = "SE_AICc.csv",
                               content = function(file){
                                           write.csv(rv$AICcTab_SE, file, 
                                           row.names = FALSE)
                                         }
                             )
    output$downloadSEfig <- downloadHandler(
                              filename = "SE_fig.png",
                              content = function(file){
                                          png(file, width = rv$figW_SE,
                                            height = rv$figH_SE, units = "px"
                                          )
                                          plot(rv$modSet_SE, 
                                            specificModel = rv$tabfig_SEpk,
                                            sizeclassName = rv$sizeclass
                                          )
                                          dev.off()
                                        }
                            )

  }
})

observeEvent(input$ltp, {
  obsColsSelected <- c(input$ltp, input$fta)
  selectedCols <- c(obsColsSelected, input$sizeclassCol, input$preds_CP)
  selectedData <- selectData(rv$data_CP, selectedCols)
  rv$colNames_CP_sel <- c(input$ltp, input$fta, input$sizeclassCol)
  rv$colNames_CP_nosel <- removeSelCols(rv$colNames_CP, rv$colNames_CP_sel)
  updateSelectizeInput(session, "preds_CP", choices = rv$colNames_CP_nosel,
    selected = input$preds_CP)

  rv$colNames_CP_sel <- c(input$ltp, input$sizeclassCol)
  rv$colNames_CP_nosel <- removeSelCols(rv$colNames_CP, rv$colNames_CP_sel)
  updateSelectizeInput(session, "fta", choices = rv$colNames_CP_nosel,
    selected = input$fta)

})
observeEvent(input$fta, {
  obsColsSelected <- c(input$ltp, input$fta)
  selectedCols <- c(obsColsSelected, input$sizeclassCol, input$preds_CP)
  selectedData <- selectData(rv$data_CP, selectedCols)
  output$selected_CP <- renderDataTable(datatable(selectedData))
  rv$colNames_CP_sel <- c(input$ltp, input$fta, input$sizeclassCol)
  rv$colNames_CP_nosel <- removeSelCols(rv$colNames_CP, rv$colNames_CP_sel)
  updateSelectizeInput(session, "preds_CP", choices = rv$colNames_CP_nosel,
    selected = input$preds_CP)

  rv$colNames_CP_sel <- c(input$fta, input$sizeclassCol)
  rv$colNames_CP_nosel <- removeSelCols(rv$colNames_CP, rv$colNames_CP_sel)
  updateSelectizeInput(session, "ltp", choices = rv$colNames_CP_nosel,
    selected = input$ltp)
})
observeEvent(input$preds_CP, {
  obsColsSelected <- c(input$ltp, input$fta)
  selectedCols <- c(obsColsSelected, input$sizeclassCol, input$preds_CP)
  selectedData <- selectData(rv$data_CP, selectedCols)
  output$selected_CP <- renderDataTable(datatable(selectedData))
  rv$colNames_CP_sel <- c(input$preds_CP, input$sizeclassCol)
  rv$colNames_CP_nosel <- removeSelCols(rv$colNames_CP, rv$colNames_CP_sel)
  updateSelectizeInput(session, "ltp", choices = rv$colNames_CP_nosel,
    selected = input$ltp)
  rv$colNames_CP_sel <- c(input$preds_CP, input$sizeclassCol)
  rv$colNames_CP_nosel <- removeSelCols(rv$colNames_CP, rv$colNames_CP_sel)
  updateSelectizeInput(session, "fta", choices = rv$colNames_CP_nosel,
    selected = input$fta)
})

observeEvent(input$runMod_CP, {

  clearNotifications(msg_SampleSizeCP = msg_SampleSizeCP)
  clearNotifications(msg_ModFailCP = msg_ModFailCP)
  msg_RunModCP <- msgModRun("CP")

  rv$ltp <- input$ltp
  rv$fta <- input$fta
  rv$preds_CP <- input$preds_CP
  rv$dists <- input$dists  
  rv$nsim <- input$nsim
  rv$CL <- input$CL
  rv$sizeclassCol <- input$sizeclassCol
  rv$predictors_CP <- prepPredictors(rv$preds_CP)
  rv$formula_l <- formula(paste("l~", rv$predictors_CP, sep = ""))
  rv$formula_s <- formula(paste("s~", rv$predictors_CP, sep = "")) 

  rv$mods_CP <- suppressWarnings(
                  cpmSetSize(formula_l = rv$formula_l,
                    formula_s = rv$formula_s, data = rv$data_CP, 
                    left = rv$ltp, right = rv$fta, dists = rv$dists,
                    sizeclassCol = rv$sizeclassCol, CL = rv$CL, quiet = TRUE
                  )
                )
  if (all(unlist(cpmSetSizeFail(rv$mods_CP)))){

    removeNotification(msg_RunModCP)
    msg_ModFailCP <<- msgModFail(rv$mod_CP)

  } else{

    if (any(unlist(pkmSetSizeFail(rv$mods_CP)))){
      msg_ModFailCP <<- msgModPartialFail()
      rv$mods_CP <- cpmSetSizeFailRemove(rv$mods_CP)
    }
    removeNotification(msg_RunModCP)
    msg_SampleSizeCP <<- msgSampleSize(rv$mod_CP)

    rv$sizeclasses <- updateSizeclasses(rv$data_CP, rv$sizeclassCol)
    rv$sizeclasses_CP <- rv$sizeclasses
    rv$sizeclass <- pickSizeclass(rv$sizeclasses, input$tabfig_sizeclassCP)
    rv$AICcTab_CP <- cpmSetAICcTab(rv$mods_CP[[rv$sizeclass]], TRUE)
    rv$AICcTab_CP[ , "Scale Formula"] <- gsub("NULL", "", 
                                           rv$AICcTab_CP[ , "Scale Formula"]
                                         )
    rv$modOrder_CP <- as.numeric(row.names(rv$AICcTab_CP))
    rv$modNames_CP <- names(rv$mods_CP[[rv$sizeclass]])[rv$modOrder_CP]
    rv$modNames_CPdist <- modNameSplit(rv$modNames_CP, 1)
    rv$modNames_CPl <- modNameSplit(rv$modNames_CP, 2)
    rv$modNames_CPs <- modNameSplit(rv$modNames_CP, 3)
    rv$modSet_CP <- rv$mods_CP[[rv$sizeclass]]
    rv$best_CP <- (names(rv$modSet_CP)[rv$modOrder_CP])[1]
    rv$modTab_CP <- rv$mods_CP[[rv$sizeclass]][[rv$best_CP]]$cellwiseTable_ls
    rv$modTab_CP <- prettyModTabCP(rv$modTab_CP, rv$CL)

    rv$figH_CP <- setFigH(rv$modSet_CP, 700, "CP")
    rv$figW_CP <- setFigW(rv$modSet_CP)

    output$CPModDone <- renderText("OK")
    outputOptions(output, "CPModDone", suspendWhenHidden = FALSE)

    output$AICcTab_CP <- renderDataTable({rv$AICcTab_CP})    
    output$modTab_CP <- renderDataTable({rv$modTab_CP})
    rv$best_CP <- gsub("NULL", "s ~ 1", rv$best_CP)
    output$fig_CP <- renderPlot({ 
                       plot(rv$modSet_CP, specificModel = rv$best_CP,
                         sizeclassName = rv$sizeclass
                       )},
                       height = rv$figH_CP, width = rv$figW_CP
                     )
    isolate({
      output$sizeclasses_CP <- prepSizeclassText(rv$sizeclasses_CP)
      outputOptions(output, "sizeclasses_CP", suspendWhenHidden = FALSE)
      output$modelMenu_CP <- makeMenu(rv$mods_CP, rv$sizeclasses_CP, "CP")
    })

    updateTabsetPanel(session, "analyses_CP", "Model Comparison")
    updateSelectizeInput(session, "tabfig_CPl", choices = rv$modNames_CPl)
    updateSelectizeInput(session, "tabfig_CPs", choices = rv$modNames_CPs)
    updateSelectizeInput(session, "tabfig_CPd", 
      choices = rv$modNames_CPdist
    )
    updateSelectizeInput(session, "tabfig_sizeclassCP", 
      choices = rv$sizeclasses
    )
    output$sizeclass_CP1 <-  renderText(paste0("Size class: ", rv$sizeclass))
    output$sizeclass_CP2 <-  renderText(paste0("Size class: ", rv$sizeclass))
  }
})

observeEvent(input$tabfig_sizeclassCP, {
  if (length(rv$mods_CP) > 0){
    rv$sizeclass <- pickSizeclass(rv$sizeclasses, input$tabfig_sizeclassCP)
    rv$AICcTab_CP <- cpmSetAICcTab(rv$mods_CP[[rv$sizeclass]], TRUE)
    rv$modOrder_CP <- as.numeric(row.names(rv$AICcTab_CP))
    rv$modNames_CP <- names(rv$mods_CP[[rv$sizeclass]])[rv$modOrder_CP]
    rv$modNames_CPdist <- modNameSplit(rv$modNames_CP, 1)
    rv$modNames_CPl <- modNameSplit(rv$modNames_CP, 2)
    rv$modNames_CPs <- modNameSplit(rv$modNames_CP, 3)
    rv$modSet_CP <- rv$mods_CP[[rv$sizeclass]]
    rv$best_CP <- (names(rv$modSet_CP)[rv$modOrder_CP])[1]
    rv$modTab_CP <- rv$mods_CP[[rv$sizeclass]][[rv$best_CP]]$cellwiseTable_ls
    rv$modTab_CP <- prettyModTabCP(rv$modTab_CP, rv$CL)
    rv$figH_CP <- setFigH(rv$modSet_CP, 700, "CP")
    rv$figW_CP <- setFigW(rv$modSet_CP)

    output$modTab_CP <- renderDataTable(rv$modTab_CP)
    rv$best_CP <- gsub("NULL", "s ~ 1", rv$best_CP)

    output$fig_CP <- renderPlot({ 
                       plot(rv$modSet_CP, specificModel = rv$best_CP,
                         sizeclassName = rv$sizeclass
                       )},
                       height = rv$figH_CP, width = rv$figW_CP
                     )

    updateSelectizeInput(session, "tabfig_CPl", choices = rv$modNames_CPl)
    updateSelectizeInput(session, "tabfig_CPs", choices = rv$modNames_CPs)
    updateSelectizeInput(session, "tabfig_CPd", 
      choices = rv$modNames_CPdist
    )

    observeEvent(input$tabfig_CPd,{
      rv$CPdls <- c(input$tabfig_CPd, input$tabfig_CPl, input$tabfig_CPs)
      rv$tabfig_CPdlsfig <- modNamePaste(rv$CPdls, "CP")
      rv$tabfig_CPdlstab <- modNamePaste(rv$CPdls, "CP", tab = TRUE)
      rv$modSet_CP <- rv$mods_CP[[rv$sizeclass]]
      rv$modTab_CP <- rv$modSet_CP[[rv$tabfig_CPdlstab]]$cellwiseTable_ls
      rv$modTab_CP <- prettyModTabCP(rv$modTab_CP, rv$CL)
      output$modTab_CP <- renderDataTable(rv$modTab_CP)
      output$fig_CP <- renderPlot({
                         tryCatch(
                           plot(rv$modSet_CP,
                             specificModel = rv$tabfig_CPdlsfig,
                             sizeclassName = rv$sizeclass
                           ), error = function(x){plot(1,1)}
                         )}, height = rv$figH_CP, width = rv$figW_CP
                       )
    })
    observeEvent(input$tabfig_CPl,{
      rv$CPdls <- c(input$tabfig_CPd, input$tabfig_CPl, input$tabfig_CPs)
      rv$tabfig_CPdlsfig <- modNamePaste(rv$CPdls, "CP")
      rv$tabfig_CPdlstab <- modNamePaste(rv$CPdls, "CP", tab = TRUE)
      rv$modSet_CP <- rv$mods_CP[[rv$sizeclass]]
      rv$modTab_CP <- rv$modSet_CP[[rv$tabfig_CPdlstab]]$cellwiseTable_ls
      rv$modTab_CP <- prettyModTabCP(rv$modTab_CP, rv$CL)
      output$modTab_CP <- renderDataTable(rv$modTab_CP)
      output$fig_CP <- renderPlot({
                         tryCatch(
                           plot(rv$modSet_CP,
                             specificModel = rv$tabfig_CPdlsfig,
                             sizeclassName = rv$sizeclass
                           ), error = function(x){plot(1,1)}
                         )}, height = rv$figH_CP, width = rv$figW_CP
                       )
    })
    observeEvent(input$tabfig_CPs,{
      rv$CPdls <- c(input$tabfig_CPd, input$tabfig_CPl, input$tabfig_CPs)
      rv$tabfig_CPdlsfig <- modNamePaste(rv$CPdls, "CP")
      rv$tabfig_CPdlstab <- modNamePaste(rv$CPdls, "CP", tab = TRUE)
      rv$modSet_CP <- rv$mods_CP[[rv$sizeclass]]
      rv$modTab_CP <- rv$modSet_CP[[rv$tabfig_CPdlstab]]$cellwiseTable_ls
      rv$modTab_CP <- prettyModTabCP(rv$modTab_CP, rv$CL)
      output$modTab_CP <- renderDataTable(rv$modTab_CP)
      output$fig_CP <- renderPlot({
                         tryCatch(
                           plot(rv$modSet_CP,
                             specificModel = rv$tabfig_CPdlsfig,
                             sizeclassName = rv$sizeclass
                           ), error = function(x){plot(1,1)}
                         )}, height = rv$figH_CP, width = rv$figW_CP
                       )
    })

    rv$AICcTab_CP <- cpmSetAICcTab(rv$mods_CP[[rv$sizeclass]], TRUE)
    rv$AICcTab_CP[ , "Scale Formula"] <- gsub("NULL", "", 
                                       rv$AICcTab_CP[ , "Scale Formula"]
                                     )
    output$AICcTab_CP <- renderDataTable(datatable(rv$AICcTab_CP))
    output$sizeclass_CP1 <-  renderText(paste0("Size class: ", rv$sizeclass))
    output$sizeclass_CP2 <-  renderText(paste0("Size class: ", rv$sizeclass))

    output$downloadCPest <- downloadHandler(
                              filename = "CP_estimates.csv",
                              content = function(file){
                                          write.csv(rv$modTab_CP, file, 
                                          row.names = FALSE)
                                        }
                            )
    output$downloadCPAICc <- downloadHandler(
                               filename = "CP_AICc.csv",
                               content = function(file){
                                           write.csv(rv$AICcTab_CP, file, 
                                           row.names = FALSE)
                                         }
                             )
    output$downloadCPfig <- downloadHandler(
                              filename = "CP_fig.png",
                              content = function(file){
                                          png(file, width = rv$figW_CP,
                                            height = rv$figH_CP, units = "px"
                                          )
                                          plot(rv$modSet_CP, 
                                           specificModel = rv$tabfig_CPdlsfig,
                                           sizeclassName = rv$sizeclass
                                          )
                                          dev.off()
                                        }
                            )
  }
})

observeEvent(input$runMod_M, {
  rv$M <- NULL
  clearNotifications(msg_ModFailM = msg_ModFailM)
  msg_RunModM <- msgModRun("M")

  rv$kFill <- NULL
  if (length(rv$obsCols_SE) == 1 | rv$kFixedChoice == 1){
    rv$kFill <- input$kFill
  }

  rv$nsizeclasses <- length(rv$sizeclasses)
  if (length(rv$nsizeclasses) == 1){
    if (is.null(rv$sizeclasses)){
      rv$sizeclasses <- "all"
     }
  }

  rv$dateFoundCol <- input$dateFoundCol
  rv$nsim <- input$nsim
  rv$frac <- input$frac
  rv$SEmodToUse <- rep(NA, rv$nsizeclasses)
  rv$CPmodToUse <- rep(NA, rv$nsizeclasses)

  for (sci in 1:rv$nsizeclasses){
    rv$SEmodToUse[sci] <- input[[sprintf("modelChoices_SE%d", sci)]]
    rv$CPmodToUse[sci] <- input[[sprintf("modelChoices_CP%d", sci)]]
    if (!grepl("s ~", rv$CPmodToUse[sci])){
      rv$CPmodToUse[sci] <- paste(rv$CPmodToUse[sci], "; NULL", sep = "")
    }
    rv$CPmodToUse[sci] <- paste("dist: ", rv$CPmodToUse[sci], sep = "")
  }
  names(rv$SEmodToUse) <- rv$sizeclasses
  names(rv$CPmodToUse) <- rv$sizeclasses

  rv$models_SE <- trimSetSize(rv$mods_SE, rv$SEmodToUse)
  rv$models_CP <- trimSetSize(rv$mods_CP, rv$CPmodToUse)

  if (rv$nsizeclasses > 1){
    rv$DWPCol <- NULL
    rv$sizeclassCol_M <- rv$sizeclassCol
  } else{
    rv$DWPCol <- input$DWPCol  
    rv$sizeclassCol_M <- NULL
    rv$models_SE <- rv$models_SE[[1]]
    rv$models_CP <- rv$models_CP[[1]]
  }

  rv$M <- tryCatch(
            estM(data_CO = rv$data_CO, data_SS = rv$data_SS, rv$data_DWP,
              frac = rv$frac, model_SE = rv$models_SE, 
              model_CP = rv$models_CP, kFill = rv$kFill, 
              dateFoundCol = rv$dateFoundCol, DWPCol = rv$DWPCol,
              sizeclassCol = rv$sizeclassCol_M, nsim = rv$nsim, max_intervals = 8
            ), error = function(x){NULL}, warning = function(x){NULL}
          )


  removeNotification(msg_RunModM)
  if (is.null(rv$M)){
    msg_ModFailM <<- msgModFail(rv$M)
  } else{

    rv$Msplit <- tryCatch(
                   calcSplits(M = rv$M$Mhat, Aj = rv$M$Aj,
                     split_SS = NULL, split_CO = NULL,
                     data_SS = rv$data_SS, data_CO = rv$data_CO
                   ), error = function(x){NULL}, warning = function(x){NULL}
                 )

    output$MModDone <- renderText("OK")
    outputOptions(output, "MModDone", suspendWhenHidden = FALSE)

    output$fig_M <- renderPlot({plot(rv$M)},
                      height = rv$figH_M, width = rv$figW_M
                    )
    output$table_M <- renderDataTable(
                        datatable(prettySplitTab(summary(rv$Msplit)))
                      )

    output$downloadMtab <- downloadHandler(
                             filename = "M_table.csv",
                             content = function(file){
                                         write.csv(
                                           prettySplitTab(summary(rv$Msplit)), 
                                           file, 
                                           row.names = FALSE
                                         )
                                       }
                           )
    output$downloadMfig <- downloadHandler(
                             filename = "M_fig.png",
                             content = function(file){
                                         png(file, width = rv$figW_M, 
                                           height = rv$figH_M, units = "px"
                                         )
                                         plot(rv$M)
                                         dev.off()
                                       }
                           )

    rv$unitCol <- intersect(rv$colNames_CO, rv$colNames_DWP)  
    rv$colNames_SS_sel <- colnames(rv$data_SS) %in% rv$data_CO[ , rv$unitCol]
    rv$colNames_SS_nosel <- rv$colNames_SS[rv$colNames_SS_sel == FALSE]
    updateSelectizeInput(session, "split_SS", choices = rv$colNames_SS_nosel)
    updateSelectizeInput(session, "split_CO", choices = rv$colNames_CO)
  }
})

observeEvent(input$splitM, {
  rv$Msplit <- NULL
  clearNotifications(msg_splitFail = msg_splitFail)

  rv$split_CO <- input$split_CO
  rv$split_SS <- input$split_SS
  rv$nsplit_CO <- length(rv$split_CO)
  rv$nsplit_SS <- length(rv$split_SS)
  if (rv$nsplit_CO + rv$nsplit_SS > 2 | rv$nsplit_SS > 1){
    msg_splitFail <<- msgsplitFail("setup")
  }
  rv$dateFoundCol <- input$dateFoundCol

  rv$Msplit <- tryCatch(
                 calcSplits(M = rv$M$Mhat, Aj = rv$M$Aj,
                   split_SS = rv$split_SS, split_CO = rv$split_CO,
                   data_SS = rv$data_SS, data_CO = rv$data_CO
                 ), error = function(x){NULL}, warning = function(x){NULL}
               )

  if (is.null(rv$Msplit)){

    msg_splitFail <<- msgsplitFail("run")
    output$fig_M <- renderPlot({plot(rv$M)},
                      height = rv$figH_M, width = rv$figW_M
                    )
    output$downloadMfig <- downloadHandler(
                             filename = "M_fig.png",
                             content = function(file){
                                         png(file, width = rv$figW_M, 
                                           height = rv$figH_M, units = "px"
                                         )
                                         plot(rv$M)
                                         dev.off()
                                       }
                           )
  } else{
    rv$figH_M <- 600
    if (length(attr(rv$Msplit, "vars")) > 1){
      rv$figH_M <- max(600, 300 * length(rv$Msplit))
    }
    output$fig_M <-  renderPlot({
                       tryCatch(plot(rv$Msplit), 
                         error = function(x){plot(1, 1)}, 
                         warning = function(x){plot(1, 1)}
                       )                     
                     }, height = rv$figH_M)

    if (is.null(rv$split_CO) & is.null(rv$split_SS)){

      output$fig_M <- renderPlot({plot(rv$M)},
                        height = rv$figH_M, width = rv$figW_M
                      )
    }

    output$table_M <- renderDataTable(
                        datatable(prettySplitTab(summary(rv$Msplit)))
                      )

    output$downloadMtab <- downloadHandler(
                             filename = "M_table.csv",
                             content = function(file){
                                         write.csv(
                                           prettySplitTab(summary(rv$Msplit)), 
                                           file, 
                                           row.names = FALSE
                                         )
                                       }
                           )
    output$downloadMfig <- downloadHandler(
                             filename = "M_fig.png",
                             content = function(file){
                                         png(file, width = rv$figW_M, 
                                           height = rv$figH_M, units = "px"
                                         )
                                         plot(rv$Msplit) 
                                         dev.off()
                                       }
                           )
  }

})

observeEvent(input$useSSdata, {
  clearNotifications(msg_avgSSfail = msg_avgSSfail)
  rv$SS <- NULL
  rv$SStemp <- tryCatch(averageSS(rv$data_SS), error = function(x){NA})
  if (is.na(rv$SStemp[1])){
    msg_avgSSfail <<- msgSSavgFail()
  } else{
    rv$SS <- rv$SStemp
    rv$avgSI <-  mean(diff(rv$SS[-length(rv$SS)]))

    updateNumericInput(session, "gSearchInterval", value = rv$avgSI)
    updateNumericInput(session, "gSearchMax", value = max(rv$SS))
    rv$SStext <- paste(rv$SS, collapse = ", ")
    output$SStext <- renderText(rv$SStext)
  }
}) 

observeEvent(input$useSSinputs, {
  rv$gSearchInterval <- input$gSearchInterval
  rv$gSearchMax <- input$gSearchMax
  rv$SS <- seq(0, rv$gSearchMax, by = rv$gSearchInterval)
  if (max(rv$SS) != rv$gSearchMax){
    rv$SS <- c(rv$SS, rv$gSearchMax)
  }
  rv$SStext <- paste(rv$SS, collapse = ", ")
  output$SStext <- renderText(rv$SStext)
})

observeEvent(input$runMod_g, {

  clearNotifications(msg_ModFailg = msg_ModFailg)
  msg_RunModg <- msgModRun("g")

  rv$CL <- input$CL
  rv$kFill_g <- NA
  if (length(rv$obsCols_SE) == 1 | rv$kFixedChoice == 1){
    rv$kFill_g <- input$kFill_g
  }
  rv$sizeclasses_g <- rv$sizeclasses
  rv$nsizeclasses_g <- length(rv$sizeclasses_g)
  if (length(rv$nsizeclasses_g) == 1){
    if (is.null(rv$sizeclasses_g)){
      rv$sizeclasses_g <- "all"
      rv$nsizeclasses_g <- 1
    }
  }

  rv$nsim <- input$nsim
  rv$gGeneric <- vector("list", length = rv$nsizeclasses_g)
  for (sci in 1:rv$nsizeclasses_g){

    rv$SEmodToUse_g <- input[[sprintf("modelChoices_SE%d", sci)]]
    rv$CPmodToUse_g <- input[[sprintf("modelChoices_CP%d", sci)]]
    if (!grepl("s ~", rv$CPmodToUse_g)){
      rv$CPmodToUse_g <- paste(rv$CPmodToUse_g, "; NULL", sep = "")
    }
    rv$CPmodToUse_g <- paste("dist: ", rv$CPmodToUse_g, sep = "")

    rv$gGeneric[[sci]] <- tryCatch(estgGeneric(
      nsim = rv$nsim, days = rv$SS,
      model_SE = rv$mods_SE[[sci]][[rv$SEmodToUse_g]],
      model_CP = rv$mods_CP[[sci]][[rv$CPmodToUse_g]],
      kFill = rv$kFill
    ), error = function(x){NULL})
  }
  names(rv$gGeneric) <- rv$sizeclasses_g

  removeNotification(msg_RunModg)

  if (!is.null(rv$gGeneric[[1]])){
    output$table_g <- renderDataTable(
                        summary(rv$gGeneric[[1]], CL = rv$CL)
                      )
    output$fig_g <- renderPlot(
                      tryCatch(
                        plot(rv$gGeneric[[1]], 
                          sizeclassName = rv$sizeclasses_g[1], CL = rv$CL
                        ), error = function(x){plot(1,1)},
                           warning = function(x){plot(1,1)}
                      )
                    )
    updateSelectizeInput(session, "tabfig_sizeclassg", 
      choices = rv$sizeclasses_g
    )
    updateTabsetPanel(session, "analyses_g", "Summary")

    output$gModDone <- renderText("OK")
    outputOptions(output, "gModDone", suspendWhenHidden = FALSE)

  } else{
    msg_ModFailg <<- msgModFail(rv$gGeneric)
  }

})

observeEvent(input$tabfig_sizeclassg, {
  rv$sizeclass_g <- pickSizeclass(rv$sizeclasses_g, input$tabfig_sizeclassg)
  rv$CL <- input$CL
  if (class(rv$gGeneric[[rv$sizeclass_g]])[1] == "gGeneric"){
    output$table_g <- renderDataTable(
                        summary(rv$gGeneric[[rv$sizeclass_g]],
                          CL = rv$CL
                        )
                      )
    output$fig_g <- renderPlot(
                      tryCatch(
                        plot(rv$gGeneric[[rv$sizeclass_g]],
                          sizeclassName = rv$sizeclass_g, CL = rv$CL
                        ), error = function(x){plot(1,1)},
                           warning = function(x){plot(1,1)}
                      )
                    )
    output$downloadgtab <- downloadHandler(
                             filename = "g_table.csv",
                             content = function(file){
                                        write.csv(
                                        summary(rv$gGeneric[[rv$sizeclass_g]],
                                        CL = rv$CL
                                        ), file, 
                                        row.names = FALSE)
                                       }
                           )
    output$downloadgfig <- downloadHandler(
                             filename = "g_fig.png",
                             content = function(file){
                                         png(file, width = rv$figW_g, 
                                           height = rv$figH_g, units = "px"
                                         )
                                         plot(rv$gGeneric[[rv$sizeclass_g]],
                                           sizeclassName = rv$sizeclass_g,
                                           CL = rv$CL
                                         )
                                         dev.off()
                                       }
                           )
  }
})

}