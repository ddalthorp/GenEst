library(GenEst)
testthat::test_check("GenEst")
