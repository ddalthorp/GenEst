## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- include=FALSE------------------------------------------------------
library(GenEst)
vers <- packageVersion("GenEst")
today <- Sys.Date()

## ------------------------------------------------------------------------
data(wind_RPbat)
names(wind_RPbat)

## ------------------------------------------------------------------------
SE_data <- wind_RPbat$SE
CP_data <- wind_RPbat$CP
SS_data <- wind_RPbat$SS
DWP_data <- wind_RPbat$DWP
CO_data <- wind_RPbat$CO

## ---- include = FALSE----------------------------------------------------
daterange <- range(SS_data$SearchDate)
seasons <- paste(unique(SS_data$Season), collapse = ', ')

## ------------------------------------------------------------------------
head(SE_data)

## ------------------------------------------------------------------------
head(CP_data)

## ------------------------------------------------------------------------
head(SS_data[, 1:10])
print("NOTE: there are 100 turbine columns altogether (t1, ..., t100)")

## ------------------------------------------------------------------------
head(DWP_data)

## ------------------------------------------------------------------------
head(CO_data)

## ---- eval = F-----------------------------------------------------------
#  SE_model <- pkm(p ~ 1, k ~ 1, data = SE_data)
#  CP_model <- cpm(l ~ 1, s ~ 1, data = CP_data, left = "Left", right = "Right")
#  
#  
#  nsim <- 1000
#    nsim = nsim; data_CO = CO_data; data_SS = SS_data;
#    data_DWP = DWP_data; frac = 1; model_SE = SE_model; model_CP = CP_model;
#    seed_SE = NULL; seed_CP = NULL; seed_g = NULL; seed_M = NULL; kFill = NULL;
#    unitCol = "Turbine"; dateFoundCol = "DateFound";
#    datesSearchedCol = "SearchDate"; DWPCol = "bat"; max_intervals = NULL;
#    sizeclassCol = NULL
#  Mest <- estM(
#    nsim = nsim, data_CO = CO_data, data_SS = SS_data,
#    data_DWP = DWP_data, frac = 1, model_SE = SE_model, model_CP = CP_model,
#    seed_SE = NULL, seed_CP = NULL, seed_g = NULL, seed_M = NULL, kFill = NULL,
#    unitCol = "Turbine", dateFoundCol = "DateFound",
#    datesSearchedCol = "SearchDate", DWPCol = "bat"
#  )
#  summary(Mest)
#  plot(Mest)
#  
#  M_season <- calcSplits(
#    M = Mest$M, Aj = Mest$Aj,
#    split_SS = "Season", data_SS = SS_data,
#    split_CO = NULL,  data_CO = CO_data
#  )
#  
#  summary(M_season)
#  plot(M_season)
#  
#  SSdat <- SS(SS_data)
#  M_week <- calcSplits(
#    M = Mest$M, Aj = Mest$Aj,
#    split_time = seq(0, max(SSdat$days), by = 7),
#    data_SS = SSdat,
#    data_CO = CO_data
#  )
#  plot(M_week, rate = T)
#  
#  M_unit <- calcSplits(
#    M = Mest$M, Aj = Mest$Aj,
#    split_CO = "Turbine",
#    data_CO = CO_data,
#    data_SS = SS_data
#  )
#  plot(M_unit, rate = F)
#  summary(M_unit)
#  summary(M_unit, CL = 0.8)
#  
#  M_unit_and_species <- calcSplits(
#    M = Mest$M, Aj = Mest$Aj,
#    split_CO = c("Turbine", "Species"),
#    data_CO = CO_data,
#    data_SS = SS_data
#  )
#  plot(M_unit_and_species, rate = F)
#  
#  
#  M_by_week_and_speciesgroup <- calcSplits(
#    M = Mest$M, Aj = Mest$Aj,
#    split_CO = "SpeciesGroup",
#    data_CO = CO_data,
#    split_time = seq(0, max(SSdat$days), by = 7),
#    data_SS = SSdat
#  )
#  plot(M_by_week_and_speciesgroup, rate = T)

