## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- include=FALSE------------------------------------------------------
library(GenEst)
vers <- packageVersion("GenEst")
today <- Sys.Date()

## ------------------------------------------------------------------------
data(wind_RPbat)
names(wind_RPbat)

## ------------------------------------------------------------------------
data_SE <- wind_RPbat$SE
data_CP <- wind_RPbat$CP
data_SS <- wind_RPbat$SS
data_DWP <- wind_RPbat$DWP
data_CO <- wind_RPbat$CO

## ---- include = FALSE----------------------------------------------------
daterange <- range(data_SS$SearchDate)
seasons <- paste(unique(data_SS$Season), collapse = ', ')

## ------------------------------------------------------------------------
head(data_SE)

## ------------------------------------------------------------------------
head(data_CP)

## ------------------------------------------------------------------------
head(data_SS[, 1:10])
print("NOTE: there are 100 turbine columns altogether (t1, ..., t100)")

## ------------------------------------------------------------------------
head(data_DWP)

## ------------------------------------------------------------------------
head(data_CO)

## ---- eval = FALSE-------------------------------------------------------
#  ?pkm

## ------------------------------------------------------------------------
model_SE <- pkm(p ~ Season, k ~ 1, data = data_SE)

## ---- eval = FALSE-------------------------------------------------------
#  ?cpm

## ------------------------------------------------------------------------
model_CP <- cpm(l ~ Season, s ~ Season, data = data_CP,
  left = "Left", right = "Right")

## ---- eval = FALSE-------------------------------------------------------
#  ?estM

## ------------------------------------------------------------------------
Mhat <- estM(nsim = 10, data_CO = data_CO, data_SS = data_SS,
  data_DWP = data_DWP, model_SE = model_SE, model_CP = model_CP,
  unitCol = "Turbine", dateFoundCol = "DateFound")

## ---- eval = FALSE-------------------------------------------------------
#  ?calcSplits

## ------------------------------------------------------------------------
M_species <- calcSplits(M = Mhat$M, Aj = Mhat$Aj, split_CO = "Species",
  data_CO = data_CO)
summary(M_species)
plot(M_species)

## ------------------------------------------------------------------------
SSdat <- SS(data_SS)

## ------------------------------------------------------------------------
M_season <- calcSplits(M = Mhat$M, Aj = Mhat$Aj,
  split_SS = "Season", data_SS = SSdat, split_CO = NULL,  data_CO = data_CO)
summary(M_season)
plot(M_season)

## ------------------------------------------------------------------------
M_month <- calcSplits(M = Mhat$M, Aj = Mhat$Aj,
  split_time = seq(0, max(SSdat$days), by = 28),
  data_SS = SSdat, data_CO = data_CO)
summary(M_month)
plot(M_month)

## ------------------------------------------------------------------------
M_various_times <- calcSplits(M = Mhat$M, Aj = Mhat$Aj,
  split_time = c(seq(0, 90, by = 15), 120, 150, seq(155, 200, by = 5)),
  data_SS = SSdat, data_CO = data_CO)
summary(M_various_times)
plot(M_various_times)
plot(M_various_times, rate = TRUE)

## ------------------------------------------------------------------------
M_species_by_season <- calcSplits(M = Mhat$M, Aj = Mhat$Aj,
  split_CO = "Species", data_CO = data_CO,
  split_SS = "Season", data_SS = SSdat)
plot(M_species_by_season)

