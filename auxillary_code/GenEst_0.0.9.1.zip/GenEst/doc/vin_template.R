## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- include=FALSE------------------------------------------------------
library(GenEst)
vers <- packageVersion("GenEst")
today <- Sys.Date()

## ------------------------------------------------------------------------
data(wind_RPbat)
names(wind_RPbat)

## ------------------------------------------------------------------------
SE_data <- wind_RPbat$SE
head(SE_data, 3)

## ----Searcher Efficiency-------------------------------------------------
SE_model <- pkm(p ~ 1, k ~ 1, data = SE_data)

## ----PKM Details, fig.show = "hold", fig.width = 5.5, fig.height = 5, fig.align = 'center'----
  SE_model$AIC
   SE_model$cellwiseTable
   plot(SE_model)

## ---- include = FALSE----------------------------------------------------
CP_data <- wind_RPbat$CP
SS_data <- wind_RPbat$SS
DWP_data <- wind_RPbat$DWP
CO_data <- wind_RPbat$CO

daterange <- range(SS_data$SearchDate)
seasons <- paste(unique(SS_data$Season), collapse = ', ')

## ------------------------------------------------------------------------
CP_data <- wind_RPbat$CP
head(CP_data, 3)

## ----Carcass persistence-------------------------------------------------
  CP_model <- cpm(l ~ Season, s ~ 1, data = CP_data, 
                  left = "Left", right = "Right", dist = "weibull")

## ----CPM Details, fig.show = "hold", fig.width = 7, fig.height = 3.3-----
   CP_model$AIC
   CP_model$cellwiseTable_ls
   plot(CP_model)

## ----Load CO SS and DWP--------------------------------------------------
CO_data <- wind_RPbat$CO
head(CO_data, 3)

## ----SS Data-------------------------------------------------------------
SS_data <- wind_RPbat$SS
SS_data[1:3 , 1:10]

## ----DWP data------------------------------------------------------------
DWP_data <- wind_RPbat$DWP
head(DWP_data, 3)

## ----Arrival Times, options----------------------------------------------
  Mest <- estM(
    nsim = 100, frac = 1, 
    data_CO = CO_data, data_SS = SS_data, data_DWP = DWP_data, 
    model_SE = SE_model, model_CP = CP_model,
    unitCol = "Turbine", 
    dateFoundCol = "DateFound", datesSearchedCol = "SearchDate"
  )

## ---- fig.show = "hold", fig.height = 4, fig.width = 6, fig.align = 'center'----
  plot(Mest)

## ----Summary - Season----------------------------------------------------

M_season <- calcSplits(
  M = Mest$M, Aj = Mest$Aj,
  split_SS = "Season", data_SS = SS_data,
  split_CO = NULL,  data_CO = CO_data
)

## ----splitFull plot, fig.height = 4, fig.width = 4, fig.align = 'center'----
plot(M_season)

## ----SplitFull Summary---------------------------------------------------
  summary(M_season, CL = 0.95)

## ----Summary - Weekly----------------------------------------------------

SSdat <- SS(SS_data) # Creates an object of type SS.
schedule <- seq(from = 0, to = max(SSdat$days), by = 7)
tail(schedule)

## ----Summary - Weekly Part 2, fig.height = 4, fig.width = 7, fig.align = 'center'----
M_week <- calcSplits(
  M = Mest$M, Aj = Mest$Aj,
  split_time = schedule, 
  data_SS = SSdat,
  data_CO = CO_data
)
plot(x = M_week, rate = T)


## ----Summary - Unit, fig.height = 4, fig.width = 7, fig.align = 'center'----

M_unit <- calcSplits(
  M = Mest$M, Aj = Mest$Aj,
  split_CO = "Turbine", 
  data_CO = CO_data, 
  data_SS = SS_data
)
plot(M_unit, rate = F)

## ----individual unit summary---------------------------------------------
dim(summary(M_unit))  # only 89 turbines had observations.

# A list of the turbines without observations:
which(!c(1:100) %in% sub(x = CO_data$Turbine,
                         pattern = "t([0-9]+)",
                         replacement = "\\1"))

# Only create summaries for turbines t8 and t100.
whichRow <- rownames(summary(M_unit))  %in% c("t8", "t100")
summary(M_unit)[whichRow, ]


## ----Summary - season and species, fig.height = 5, fig.width = 3, fig.align = 'center'----

M_unit_and_species <- calcSplits(
  M = Mest$M, Aj = Mest$Aj,
  split_SS = c("Season"),
  split_CO = c("Species"),
  data_CO = CO_data,
  data_SS = SS_data
)
plot(M_unit_and_species, rate = F)


## ----Summary - week and species, fig.height = 4.5, fig.width = 4, fig.align = 'center'----
M_by_week_and_speciesgroup <- calcSplits(
  M = Mest$M, Aj = Mest$Aj,
  split_CO = c("TurbineType", "SpeciesGroup"),
  data_CO = CO_data
)
plot(M_by_week_and_speciesgroup, rate = T)


